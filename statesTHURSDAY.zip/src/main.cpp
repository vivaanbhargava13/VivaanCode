// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// gyroo                inertial      20              
// intake               motor         15              
// catapult             motor         4               
// left_v               digital_out   H               
// left_h               digital_out   E               
// right_v              digital_out   G               
// Controller1          controller                    
// RotationRight        rotation      21              
// RotationLeft         rotation      3               
// backleft             motor         17              
// middleleft           motor         16              
// frontleft            motor         12              
// backright            motor         18              
// middleright          motor         13              
// frontright           motor         1               
// cata2                motor         19              
// right_h              digital_out   F               
// pto                  digital_out   A               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "functions.h"

using namespace vex;

// A global instance of competition
competition Competition;

// reform of old function
void forwardPIDD(int setpoint, int speed, int timeout=2500) {
  backleft.setPosition(0,degrees);
  float input = backleft.position(degrees);
  float power;
  float kP = 0.1 * (.01 * speed);
  // float kI = 0.0002;
  float kD = 0.3;
  
  float error = setpoint - input;
  // float integral = 0;
  float derivative = 0;
  float prevError = 0;
  timer Timer;
  float i = 1;
  while (abs(error) > i && (Timer.time()<timeout||timeout == -1)) {
    input = backleft.position(degrees);
    error = setpoint - input;
      float P = kP * error;
        // integral += error;
      // float I = kI * integral;
        derivative = error - prevError;
      float D = kD * derivative;
      power = P + D; 
  
    frontleft.spin(forward, power, pct);
    frontright.spin(forward, power, pct);
    middleleft.spin(forward, power, pct);
    middleright.spin(forward, power, pct);
    backleft.spin(forward, power, pct);
    backright.spin(forward, power, pct);
    prevError = error;
    wait(10, msec);
  }
    stopBase(); // Stop the drivetrain when the loop exits
}

// void curvePID(int setpoint, int speedLeft, int speedRight) {
//   backleft.setPosition(0,degrees);
//   float input = backleft.position(degrees);
//   float rightpower;
//   float leftpower;
//   float lkP = 0.14 * (.01 * speedLeft);
//   float rkP = 0.14 * (.01 * speedRight);
//   // float kI = 0.0002;
//   float kD = 0.5;
  
//   float error = setpoint - input;
//   // float integral = 0;
//   float derivative = 0;
//   float prevError = 0;
  
//   float i = 1;
//   while (abs(error) > i) {
//     input = backleft.position(degrees);
//     error = setpoint - input;
//       float lP = lkP * error*(0.625);
//       float rP = rkP * error*(0.625);
//       // integral += error;
//       // float I = kI * integral;
//       derivative = error - prevError;
//       float D = kD * derivative;
//       rightpower = rP + D; 
//       leftpower = lP + D;
  
//     frontleft.spin(forward, leftpower, pct);
//     frontright.spin(forward, rightpower, pct);
//     middleleft.spin(forward, leftpower, pct);
//     middleright.spin(forward, rightpower, pct);
//     backleft.spin(forward, leftpower, pct);
//     backright.spin(forward, rightpower, pct);
//     prevError = error;  
//     wait(10, msec);
//   }
//     stopBase(); // Stop the drivetrain when the loop exits
// }


void sensordisplays () {
  while (true) {
    // Brain.Screen.printAt(15, 15, "%f", RotationRight.position(degrees));
    // Brain.Screen.printAt(30, 30, "%f", RotationLeft.position(degrees));
    // Brain.Screen.printAt(45, 45, "%f", gyroo.heading(degrees));
    // Brain.Screen.printAt(60, 60, "Hue: %.2f", Opticall.hue());
    wait(10,msec);
    Brain.Screen.clearScreen();
  }
}

void clearmotors () {
  frontleft.resetPosition();
  frontright.resetPosition();
  backleft.resetPosition();
  backright.resetPosition();
  middleleft.resetPosition();
  middleright.resetPosition();
}

void clearall() {
  clearmotors();
  gyroo.resetHeading();
  RotationLeft.resetPosition();
  RotationRight.resetPosition();
}

void sWings(int setpoint) {
  left_h.set(setpoint);
  right_h.set(setpoint);
}

void startHorizontal(){
  left_h.set(true);
  right_h.set(true);
  wait(0.25, sec);
  left_h.set(false);
  right_h.set(false);
}

void wingsDef(){
  left_h.set(true);
  wait(0.25, sec);
  left_h.set(false);
}

void score3(){
  left_h.set(true);
  right_h.set(true);
  wait(.85, sec);
  left_h.set(false);
  right_h.set(false);
}

void defOverBar(){
  left_h.set(true);
  wait(1, sec);
  left_h.set(false);
}

void vWings(int setpoint) {
  left_v.set(setpoint);
  right_v.set(setpoint);
}

void descoreWings(){
  left_v.set(true);
  right_v.set(true);
  wait(0.5, sec);
  left_v.set(false);
  right_v.set(false);

}

void leftDef(){
  left_h.set(true);
  wait(400, msec);
  left_h.set(false);
}


void punch(){
  while(true){
    while (Controller1.ButtonY.pressing()) {
      catapult.spin(reverse, 100, pct);
      cata2.spin(reverse, 100, pct);
    }  
    catapult.stop(hold);
    cata2.stop(hold);
  }
}

void finishHang(){
  while(true){
    while (Controller1.ButtonX.pressing()) {
      catapult.spin(forward, 100, pct);
      cata2.spin(forward, 100, pct);
    }  
    catapult.stop(hold);
    cata2.stop(hold);
  }
}


void hangpto(){
  bool ptobool = false;
  while(true){
    if (Controller1.ButtonB.pressing()){
      pto.set(!ptobool);    
    }
  }
}

void pre() {
  clearall();
  // thread d(autofire);
  //Controller1.Screen.setCursor(2,2);
  //Controller1.Screen.print("Calibrating sensors...");
  gyroo.calibrate();
  wait(2.5, seconds);
  //Controller1.Screen.setCursor(2,2);
  //Controller1.Screen.print("      We're live!       ");
  wait(2, seconds);
  //Controller1.Screen.setCursor(2,2);
  //Controller1.Screen.print("      Go Luca !!!       ");
}

void clearLine(){
  left_h.set(true);
  right_h.set(true);
  wait(1.5, sec);
  left_h.set(false);
  right_h.set(false);
}


void skills() {
    // // PART I
  //  // match loads into goal
  //   turnPID(25, 85, -1);
  //     clearmotors();
  //   forwardPIDD(-1700, 100, 1100);
  //     clearmotors();
  //     clearmotors();
  //   //safety bump
  //   forwardPIDD(400, 100, 300);
  //     clearmotors();
  //   turnPID(0, 85, -1);
  //     clearmotors();
  //  // set up for match loaders
  //   forwardPIDD(800, 100, 700);
  //     clearmotors();
  //   turnPID(110, 85, -1);
  //     clearmotors();
  //   forwardPIDD(-200, 100, 100);
  //     clearmotors();
  //   wait(.1, sec);
  //   forwardPIDD(300, 100, 100);
  //     clearmotors();
  //   turnPID(120, 85, -1);
  //   svertical(true);
  //   // catapult spin here or something
  //   wait(.5, sec);
  //   svertical(false);
  //   // move into position to clear
  //   forwardPIDD(1250, 95, 950);
	//     clearmotors();
  //   turnPID(90, 83, -1);
	//     clearmotors();
  //   forwardPIDD(800, 100, 600);
	//     clearmotors();
  //  //clear the line
  //   turnPID(180, 80, -1);
	//     clearmotors();
  //     sright(true);
  //     intake.spin(reverse, 100, pct);
  //   forwardPIDD(3500, 100, 2800);
	//     clearmotors();
  //   // just in case smack it again
  //   forwardPIDD(-600, 100, 500);
	//     clearmotors();
  //   forwardPIDD(700, 100, 500);
	//     clearmotors();
  //     sright(false); // fold up
  //     intake.stop();
  //  // move to turn and cross under the bar
  //   forwardPIDD(-500, 100, 300);
	//     clearmotors();
  //   turnPID(90, 85, -1); // face the right way
	//     clearmotors();
  //   forwardPIDD(-300, 100, 200);
  //     clearmotors();
  //   turnPID(85, 85, -1); // turn
  //     clearmotors();
  //   forwardPIDD(-1700, 100, 1200);
  //     clearmotors();
  //   turnPID(130, 85, -1); // turn again
  //     clearmotors();
  //   forwardPIDD(1000, 100, 800);
  //     clearmotors();
  //   turnPID(90, 85, -1); // 1 last time
  //   forwardPIDD(2700, 100, 2000); // cross
  //     clearmotors();
    // push first corner !!!
    right_h.set(true);
    turnPID(90, 85, -1);
    wait(.1, sec);
    turnPID(50, 85, -1);
      clearmotors();
    intake.spin(reverse, 100, pct);
    forwardPIDD(1500, 100, 1000);
      clearmotors();
    turnPID(0, 85, -1); // adjust veryy slightly
      clearmotors();
    forwardPIDD(700, 100, 500);
      clearmotors();
    forwardPIDD(-800, 100, 300); // backup ram
      clearmotors();
    forwardPIDD(700, 100, 1100); // pow! lets get started on the hard part ...
      clearmotors();
  // PART II
    right_h.set(false);
    forwardPIDD(-600, 100, 500); // back out of the net
    turnPID(-90, 85, -1);
      clearmotors();
    intake.stop();
    forwardPIDD(2100, 100, 1700); // head to bar and prep to do stuff
      clearmotors();
    turnPID(0, 85, -1); //line up
      clearmotors();
    forwardPIDD(1000, 100, 600);
      clearmotors();
    turnPID(90, 85, -1); // line up
      clearmotors();
    
    right_h.set(true); 
    left_h.set(true); // prep
      intake.spin(reverse, 100, pct);
    forwardPIDD(1300, 100, 800); // gooo
      clearmotors();
    forwardPIDD(-800, 100, 600);
      clearmotors();
    forwardPIDD(900, 100, 700); // just in case ram
      clearmotors();
    forwardPIDD(-1300, 100, 800); // backup
      intake.stop();
      clearmotors();
    right_h.set(false);
    left_h.set(false);
     // fold
    turnPID(0, 85, -1);
      clearmotors();
    forwardPIDD(1000, 100, 700);
      clearmotors();
    
    // HUZZAH SMACK SMACK SLAMMMMOOOOOO
    turnPID(90, 85, -1);
      clearmotors();
      right_h.set(true);
      left_h.set(true);
    intake.spin(reverse, 100, pct);
    forwardPIDD(1400, 100, 1000);
      clearmotors();
    forwardPIDD(-900, 100, 700);
      clearmotors();
    forwardPIDD(1000, 100, 800); // just in case ram
      clearmotors();
    forwardPIDD(-1700, 100, 1000);
      clearmotors();
      intake.stop();
      right_h.set(false);
      left_h.set(false);
    
    // last forward facing tribal circuit
    turnPID(0, 85, -1);
      clearmotors();
    forwardPIDD(1300, 100, 1000);
      clearmotors();
    
    intake.spin(reverse, 100, pct);
    right_h.set(true);
    left_h.set(true);
    turnPID(125, 75, -1); // line up
      clearmotors();
    forwardPIDD(2000, 100, 1600);
      clearmotors();
    forwardPIDD(-1000, 100, 700); // just in case
      clearmotors();
    forwardPIDD(1100, 100, 800);
      clearmotors();
    forwardPIDD(-1000, 100, 800);
      clearmotors();
    intake.stop();
    right_h.set(false);
    left_h.set(false);
    forwardPIDD(-700, 100, 300);
    turnPID(45, 85, -1);
    forwardPIDD(2000, 100, 1000);
    right_h.set(true);
    turnPID(135, 65, -1);
    forwardPIDD(1000, 100, 1000);
    forwardPIDD(-500, 100, 350);
    turnPID(180, 65, -1);
    forwardPIDD(700, 100, 500);
    wait(0.1, sec);
    forwardPIDD(-500, 100, 350);
    forwardPIDD(700, 100, 500);
    wait(0.1, sec);
    forwardPIDD(-500, 100, 350);
    turnPID(-35, 85, -1);
    forwardPIDD(1200, 100, 1000);
    turnPID(-90, 85, -1);
    forwardPIDD(500, 100, 200);
}

void vivaanOff(){
  // hit the preload towards the goal
  thread h(startHorizontal);
  // speed towards the center triball and intake
  intake.spin(forward, 100, pct);
  forwardPIDD(2375, 100, 1000);
  wait(50, msec);
  intake.stop();
  //score it
  turnPID(-100, 85, -1);
  wait(0.01, sec);
  intake.spin(reverse, 100, pct);
  wait(.03, sec);
  forwardPIDD(800, 100, 900);
  forwardPIDD(-400, 100, 300);
  intake.stop();
  //go towards the triball diagonal from the goal and pick it up BUT DO NOT OUTTAKE
  turnPID(95.5, 85, -1);  
  intake.spin(forward, 100, pct);
  forwardPIDD(1000, 100, 750);
  wait(0.02, sec);
  forwardPIDD(-100, 100, 150);
  // turn facing 180 degrees (backside towards) the corner bar we started next to,
  // go all the way back to it, wings out, descore corner triball
  turnPID(32.5, 85, -1);
  intake.stop();
  forwardPIDD(-2420, 100, 1100);
  turnPID(104, 85, -1);
  vWings(true);
  wait(0.02, sec);
  forwardPIDD(200, 100, 175);
  forwardPIDD(-450, 100, 500);
  turnPID(145, 85, -1);
  vWings(false);
  turnPID(-39.5, 85, -1);
  // outtake the triball that we picked up earlier and push it in along with the preload
  // we flicked towards the goal at the start, and hopefully the triball from the corner
  intake.spin(reverse, 100, pct);
  thread p(score3);
  forwardPIDD(700, 100, 850);
  wait(.02, sec);
  forwardPIDD(-200, 100, 300);
  forwardPIDD(500, 100, 500);
  intake.stop();
  // back out, turn towards the lane, and go to touch the bar
  forwardPIDD(-600, 100, 750);
  turnPID(100.5, 85, -1);
  forwardPIDD(1320, 100, 1000);
  turnPID(73, 85, -1);
  // try and intake the triball in the middle so it doesnt count against us in any manner 
  forwardPIDD(1050, 70, 1000);
}

void vivaanDef(){
    // hit the preload towards the goal
  thread h(wingsDef);
    // speed to the center, turn, and sweep the two middle two triballs away. 
  forwardPIDD(2100, 100, 900);
  turnPID(-90, 85, -1);
  thread o(defOverBar);
  forwardPIDD(1600, 100, 900);  
  forwardPIDD(-400, 100, 200);
  turnPID(-45, 85, -1);
  forwardPIDD(-2600, 100, 1450);
  thread d(descoreWings);
  turnPID(45, 85, -1);
  wait(0.2, sec);
  turnPID(-135, 85, -1);
  forwardPIDD(-800, 100, 750);
  turnPID(-165, 85, -1);
  forwardPIDD(-500, 100, 400);
  forwardPIDD(500, 100, 200);
  forwardPIDD(-500, 100, 200);
  forwardPIDD(275, 100, 200);
  turnPID(-130, 85, -1);
  forwardPIDD(1200, 100, 1100);
  turnPID(-90, 85, -1);
  intake.spin(reverse, 100, pct);
  forwardPIDD(1400, 100, 1500);
  // THE FOLLOWING AUTON WORKED FOR SCORING AWP... A WHILE AGO???
    // vWings(true);
    // wait(.7, seconds);
    // turnPID(40, 100, -1);
    // vWings(false);
    // wait(.13, seconds);
    // turnPID(37, 100, -1);
    // wait(5, msec);
    // forwardPIDD(1000, 100);
    // wait(5, msec);
    // turnPID(0, 100, -1);
    // wait(5, msec);
    // intake.spin(reverse, 100, pct);
    // forwardPIDD(100, 100);
    // wait(.35, seconds);
    // forwardPIDD(-400, 100);
    // intake.stop();
    // turnPID(180, 100, -1);
    // forwardPIDD(-375, 100);
    // wait(10, msec);
    // forwardPIDD(200, 75);
    // turnPID(-120, 100, -1);
    // forwardPIDD(1400, 100);
    // turnPID(-92 , 100, -1);
    // forwardPIDD(1025, 100);
    // intake.spin(reverse, 100, pct);
}
void sleft(int left) {
left_h.set(left);
}

void sright( int right) {
right_h.set(right);
}


/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*---------------------------------------------------------------------------*/
int current_auton_selection;
bool auto_started;
void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  pre();
  while(auto_started == false){            //Changing the names below will only change their names on the
    Brain.Screen.clearScreen();            //brain screen for auton selection.
    switch(current_auton_selection){       //Tap the brain screen to cycle through autons.
      case 0:
        Brain.Screen.printAt(50, 50, "Auton 1");
        break;
      case 1:
        Brain.Screen.printAt(50, 50, "Auton 2");
        break;
      case 2:
        Brain.Screen.printAt(50, 50, "Auton 3");
        break;
      case 3:
        Brain.Screen.printAt(50, 50, "Auton 4");
        break;
      case 4:
        Brain.Screen.printAt(50, 50, "Auton 5");
        break;
      case 5:
        Brain.Screen.printAt(50, 50, "Auton 6");
        break;
      case 6:
        Brain.Screen.printAt(50, 50, "Auton 7");
        break;
      case 7:
        Brain.Screen.printAt(50, 50, "Auton 8");
        break;
    }
    if(Brain.Screen.pressing()){
      while(Brain.Screen.pressing()) {}
      current_auton_selection ++;
    } else if (current_auton_selection == 8){
      current_auton_selection = 0;
    }
    task::sleep(10);
  }
}

/*---------------------------------------------------------------------------*/
/*                              Auton Task                                  */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  vivaanOff();
// auto_started = true;
//   switch(current_auton_selection){  
//     case 0:
//       vivaanDef(); //This is the default auton, if you don't select from the brain.
//       break;        //Change these to be your own auton functions in order to use the auton selector.
//     case 1:         //Tap the screen to cycle through autons.
//       //far_side_auton();
//       break;
//     case 2:
//       //skills_auton();
//       break;
//     case 3:
//       //swing_test();
//       break;
//     case 4:
//       //full_test();
//       break;
//     case 5:
//       //odom_test();
//       break;
//     case 6:
//       //tank_odom_test();
//       break;
//     case 7:
//       //holonomic_odom_test();
//       break;
//  }
}

/*---------------------------------------------------------------------------*/
/*                              User Control Task                            */
/*---------------------------------------------------------------------------*/

int caxis1 = 1;
int caxis3 = 1;
int caxis1B = 1;

void usercontrol(void) {
  // intakepistonb.set(true);
  catapult.setStopping(hold);
  stopBase();
  while (true) {
  //CODE BELOW, IF YOU WANT TO REMOVE EXPONENTIAL TURNING, COMMENT IT ALL OUT
  //BUT LEAVE THE TOP IF STATEMENT, THEN write caxis1=Conroller1.Axis1.position
    thread p(punch);
    thread h(hangpto);
    thread f(finishHang);

    middleleft.spin(forward, (Controller1.Axis3.position(percent) + Controller1.Axis1.position(pct)), percent);
    middleright.spin(forward, (Controller1.Axis3.position(percent) - Controller1.Axis1.position(pct)), percent);
    frontleft.spin(forward, (Controller1.Axis3.position(percent) + Controller1.Axis1.position(pct)), percent);
    frontright.spin(forward, (Controller1.Axis3.position(percent) - Controller1.Axis1.position(pct)), percent);
    backright.spin(forward, (Controller1.Axis3.position(percent) - Controller1.Axis1.position(pct)), percent);
    backleft.spin(forward, (Controller1.Axis3.position(percent) + Controller1.Axis1.position(pct)), percent);

  if((Controller1.Axis3.position()>-5 && Controller1.Axis3.position()<5) && (Controller1.Axis1.position()>-5 && Controller1.Axis1.position()<5)){
    middleright.stop(coast),
    middleleft.stop(coast),
    frontright.stop(coast),
    frontleft.stop(coast),
    backright.stop(coast),
    backleft.stop(coast);
  }
    if (Controller1.ButtonR2.pressing()) {
      (intake.spin(reverse, 90, pct));
    } else if (Controller1.ButtonR1.pressing()) {
      (intake.spin(forward, 90, pct));
    } else {
      intake.stop();
    }
    // pneu wings
    if (Controller1.ButtonL2.pressing()||Controller1.ButtonLeft.pressing())
    {
      left_h.set(true);
    }
    else{
      left_h.set(false);
    }
    if (Controller1.ButtonL2.pressing()||Controller1.ButtonRight.pressing())
    {
      right_h.set(true);
    }
    else{
      right_h.set(false);
    }
    if (Controller1.ButtonL1.pressing()||Controller1.ButtonUp.pressing())
    {
      left_v.set(true);
    }
    else{
      left_v.set(false);
    }
    if (Controller1.ButtonL1.pressing()||Controller1.ButtonDown.pressing())
    {
      right_v.set(true);
    }
    else{
      right_v.set(false);
    }
  

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}


// Main will set up the competition functions and callbacks.

int main() { 
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}